#include <iostream>

#include <module1/mod1c1.hpp>

void mod1c1::foo()  { std::cout << "mod1c1\n"; }

