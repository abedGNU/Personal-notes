#ifndef MOD1C2_HPP
#define MOD1C2_HPP

#include <iostream>

class mod1c2
{
public:

   void foo(); // { std::cout << "mod1c1\n"; }

};

#endif

