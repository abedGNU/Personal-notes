Makefile Tutorial by Example
========

This is a single page website that has index.html, which is created by the file `index.md`.

Pull requests are welcome!

Design from [white-paper](https://github.com/vinitkumar/white-paper).
