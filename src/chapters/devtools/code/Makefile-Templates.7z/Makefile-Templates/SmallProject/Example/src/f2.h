#ifndef __F2_H__
#define __F2_H__

int f2(int a, int b);

#endif