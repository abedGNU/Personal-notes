#ifndef __F1_H__
#define __F1_H__

int f1(int a, int b);

#endif