#include <iostream>
#include "f1.h"
#include "f2.h"

int main() {
    std::cout << f1(1, 2) << std::endl;
    std::cout << f2(2, 3) << std::endl;
    return 0;
}