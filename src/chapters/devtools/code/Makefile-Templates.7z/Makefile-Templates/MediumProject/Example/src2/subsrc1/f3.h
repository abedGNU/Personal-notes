#ifndef __F3_H__
#define __F3_H__

int f3(int a, int b);

#endif