#include "f3.h"

int f3(int a, int b) { return a * b; }